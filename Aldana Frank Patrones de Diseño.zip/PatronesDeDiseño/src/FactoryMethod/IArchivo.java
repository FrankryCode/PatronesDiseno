//Producto
package FactoryMethod;

/**
 *
 * @author Frank
 */
public interface IArchivo {
    public void reproducir();
}
