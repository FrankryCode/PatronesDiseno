
package Iterator;

/**
 *
 * @author Frank
 */
public interface Agregado {
    public Iterador getIterador();
}
