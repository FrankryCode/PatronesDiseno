//IComponente
package Decorator;

/**
 *
 * @author Frank
 */
public interface IVentana {
    public void dibujar(int columna, int fila);
    
}
