/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facade;

/**
 *
 * @author Frank
 */
public class Arrancar {

    public Arrancar() {
    }

    // ------------------
    public void encenderContacto() {
        System.out.println("Introducimos la llave y le damos al encendido...");
    }
}
