package Facade;

/**
 *
 * @author Frank
 */
public class ComprobarEspejos {

    public ComprobarEspejos() {
    }

    // ------------------
    public void comprobar() {
        System.out.println("Comprobamos y regulamos los espejos retrovisores...");
    }
}
