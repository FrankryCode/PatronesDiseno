//
package Facade;

/**
 *
 * @author Frank
 */
public class ComprobarLiquidos {

    public ComprobarLiquidos() {
    }

    // ------------------
    public void comprobar() {
        System.out.println("Comprobamos los líquidos de freno, agua, etc...");
    }
}
