package Facade;

/**
 *
 * @author Frank
 */
public class ComprobarAsiento {

    public ComprobarAsiento() {
    }

    // ------------------
    public void comprobar() {
        System.out.println("Comprobamos y regulamos el asiento...");
    }
}
