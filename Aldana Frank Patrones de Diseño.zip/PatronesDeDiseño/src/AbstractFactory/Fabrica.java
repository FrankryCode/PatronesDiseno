//fabrica abstracta
package AbstractFactory;

/**
 *
 * @author Frank
 */
public interface Fabrica {
    public Television crearTelevision();
    public Celular crearCelular();
}
