//Producto Abstracto
package AbstractFactory;

/**
 *
 * @author Frank
 */
public interface Television {
        public void marca();
}
