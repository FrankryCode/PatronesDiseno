//Producto concreto
package AbstractFactory;

/**
 *
 * @author Frank
 */
public class LgTelevision implements Television {
    
    @Override
    public void marca(){
        System.out.println("Television marca LG");
    }
    
    
}
