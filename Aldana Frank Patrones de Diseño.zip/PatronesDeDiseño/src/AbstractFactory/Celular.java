//Producto Abstracto
package AbstractFactory;

/**
 *
 * @author Frank
 */
public interface Celular {
    public void marca();
}
