
package AbstractFactory;

/**
 *
 * @author Frank
 */
public class SonyCelular implements Celular{

    @Override
    public void marca() {
        System.out.println("Celular marca Sony");
    }
    
}
