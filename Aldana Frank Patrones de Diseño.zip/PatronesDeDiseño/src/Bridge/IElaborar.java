
package Bridge;

/**
 *
 * @author Frank
 */
public interface IElaborar {
    public void procesar();
}
