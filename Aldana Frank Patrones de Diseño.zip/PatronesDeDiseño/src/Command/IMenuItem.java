package Command;

/**
 *
 * @author Frank
 */
public interface IMenuItem {

    public void ejecutar();
}
