//Sujeto
package Proxy;

/**
 *
 * @author Frank
 */
public interface  Imagen {

    public void mostrarImagen();
}
