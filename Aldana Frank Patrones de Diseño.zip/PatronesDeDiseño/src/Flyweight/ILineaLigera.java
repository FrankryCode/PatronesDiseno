//Peso ligero
package Flyweight;

/**
 *
 * @author Frank
 */
public interface ILineaLigera {
    public String getColor();
     public void dibujar( int col, int fila );
}
